#include <stdio.h>

int main()
{
	char inChar1;
	char inChar2;

	printf("Are you an ECE student? (y/n): \n");
	inChar1 = getchar();

	printf("Are you taking ECE220? (y/n): \n");
	inChar2 = getchar();

	printf("Here are your inputs:\n");
	printf("Are you an ECE student? %c\n", inChar1);
	printf("Are you taking ECE220? %c\n", inChar2);

	return 0;
}
