#include <stdio.h>

int main()
{
	FILE *file;
	int i;

	//open a file for write 
	//use fputc to write one character at a time
	file = fopen("test.txt", "w");
	if(file == NULL){
		printf("Cannot open file for write.\n");
		return -1;
	}
	for(i=48;i<=90;i++){
		fputc(i, file);
	}

	fclose(file); 
	
	//open the same file for read
	//use fgetc and EOF to read one character at a time
	file = fopen("test.txt", "r");
	if(file == NULL){
		printf("Cannot open file for read. \n");
		return -1;
	}
	while(1){
		i = fgetc(file);
		if(i == EOF)
		{
			break;
		}
		printf("%c", i);
	}
	printf("\n");
	
	fclose(file);

	return 0;
}
