#include <stdlib.h>
#include <string.h>
#include <stdio.h>


typedef struct studentStruct
{
	char *NAME;
	int UIN;
	float GPA;
}student;

int main()
{
	student* stdlist;
	stdlist = (student*)malloc(200*sizeof(student));

	int i;
	for (i=0;i<200;i++)
	  {
	    (stdlist + i)->UIN= 0;
	    (stdlist + i)->GPA= 0.0;
	    (stdlist + i)->NAME= (char*)malloc(100*sizeof(char));
	    strcpy( (stdlist + i)->NAME, "to be set");
	  }

	printf("student_list pointer %p\n",stdlist);
	
	student *newstdlist = realloc(stdlist, 400*sizeof(student));
	for (i=200;i<400;i++)
	  {
	    (newstdlist + i)->UIN= 0;
	    (newstdlist + i)->GPA= 0.0;
	    (newstdlist + i)->NAME= (char*)malloc(100*sizeof(char));
	    strcpy( (newstdlist + i)->NAME, "to be set");
	  }

	printf("new student_list pointer %p\n",newstdlist);
	
	for(i=0;i<400;i++)
        {
		//printf("Student No.%d - Name:%s, UIN:%d, GPA:%f\n", i+1, (new_student_list+i)->NAME, (new_student_list+i)->UIN, (new_student_list+i)->GPA);
                free((newstdlist+i)->NAME);
        }

	free(newstdlist);

}
